package seng202;


public class Main {

    public static void main(String[] args) {
        SampleApplication.main(args);
    }
}
